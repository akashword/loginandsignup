package com.jpa.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpa.Dto.LoginDto;
import com.jpa.Dto.UserDto;
import com.jpa.Entity.User;
import com.jpa.Repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	public void saveUser(UserDto userDto) {
		userRepository.save(userDtoToUser(userDto));
	}
	
	//fetch data by mobile number
	public UserDto signupByMobile(String mobileNumber) {
		User user=this.userRepository.findByMobileNumber(mobileNumber);
		return userToUserDto(user);
	}
	
	//login
	public String login(LoginDto loginDto) {
		User user=this.userRepository.findOneByIgnoreCaseEmailIdAndPassword(loginDto.getEmaiId(),loginDto.getPassword());
		if(user==null)
			return "Not login";
		else
			return"Logged in";
	}
	public User userDtoToUser(UserDto userDto) {
		User user = new User();

		user.setId(userDto.getId());
		user.setFirstName(userDto.getFirstName());
		user.setSurName(userDto.getSurname());
		user.setMobileNumber(userDto.getMobileNumber());
		user.setEmailId(userDto.getEmailId());
		user.setPassword(userDto.getPassword());
		user.setDob(userDto.getDob());
		user.setGender(userDto.getGender());
		return user;
	}

	public UserDto userToUserDto(User user) {
		UserDto userDto = new UserDto();

		userDto.setId(user.getId());
		userDto.setFirstName(user.getFirstName());
		userDto.setSurname(user.getSurName());
		userDto.setMobileNumber(user.getMobileNumber());
		userDto.setEmailId(user.getEmailId());
		userDto.setPassword(user.getPassword());
		userDto.setDob(user.getDob());
		userDto.setGender(user.getGender());
		return userDto;
	}
	

}
