package com.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springjpa2Application {

	public static void main(String[] args) {
		SpringApplication.run(Springjpa2Application.class, args);
	}

}
