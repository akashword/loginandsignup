package com.jpa.signup.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.jpa.Service.CustomUserService;

@Configuration
public class MySecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Autowired
	CustomUserService customUserService;
	
	
	@Override
	protected void configure(HttpSecurity http)throws Exception{
		http.csrf().disable()
		
		.authorizeRequests()
		.antMatchers("/swagger-ui/**")
		.hasAnyAuthority()
		.anyRequest()
		.authenticated()
		.and()
		.formLogin().and().logout()	
		.permitAll();
	}
	
     protected void configure(AuthenticationManagerBuilder auth) throws Exception{
   	 auth.userDetailsService(this.customUserService).passwordEncoder(passwordEncoder());
//		auth.inMemoryAuthentication().withUser("Akash").password(this.passwordEncoder().encode("Akash")).roles("NORMAL");
//   	auth.inMemoryAuthentication().withUser("Aman").password(this.passwordEncoder().encode("AMAN")).roles("ADMIN");
    }
     
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
    	return new BCryptPasswordEncoder(10);
    }
}
