package com.jpa.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpa.Entity.User;

public interface UserRepository extends JpaRepository<User,Long>{

	 User findByMobileNumber(String mobileNumber);
	Optional<User>findByEmailId(String emailid);
	User findOneByIgnoreCaseEmailIdAndPassword(String emailId,String password);
}
